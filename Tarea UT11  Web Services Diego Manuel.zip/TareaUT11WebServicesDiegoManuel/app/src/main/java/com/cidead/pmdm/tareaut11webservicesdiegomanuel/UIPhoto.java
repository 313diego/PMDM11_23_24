package com.cidead.pmdm.tareaut11webservicesdiegomanuel;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import com.cidead.pmdm.tareaut11webservicesdiegomanuel.Modelo.Curiosity;

public interface UIPhoto {
    @GET("curiosity/photos?sol=1000")
    Call<Curiosity> getPhotos(@Query("api_key") String key);
}
