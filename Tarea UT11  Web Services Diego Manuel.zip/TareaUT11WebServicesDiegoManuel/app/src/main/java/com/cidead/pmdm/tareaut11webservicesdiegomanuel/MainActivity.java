package com.cidead.pmdm.tareaut11webservicesdiegomanuel;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.cidead.pmdm.tareaut11webservicesdiegomanuel.Modelo.Curiosity;
import com.squareup.picasso.Picasso;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MainActivity extends AppCompatActivity {

    EditText eTApi;
    NumberPicker nPFoto;
    Button bTMostrar;
    ImageView iVFoto;
    String mensaje = "Debe de rellenar el API para poder mostrar las imagenes";
    final String URL = "https://api.nasa.gov/mars-photos/api/v1/rovers/";;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        eTApi = (EditText) findViewById(R.id.eTApi);
        nPFoto = (NumberPicker) findViewById(R.id.nPFoto);
        bTMostrar = (Button) findViewById(R.id.bTMostrar);
        iVFoto = (ImageView) findViewById(R.id.iVFoto);
        nPFoto.setMinValue(0);
        nPFoto.setMaxValue(855);
        bTMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(eTApi.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), mensaje, Toast.LENGTH_LONG).show();
                }else{
                    Retrofit retrofit = new Retrofit.Builder()
                            .baseUrl(URL)
                            .addConverterFactory(GsonConverterFactory.create())
                            .build();

                    UIPhoto uiPhoto = retrofit.create(UIPhoto.class);
                    Call<Curiosity> call = uiPhoto.getPhotos(eTApi.getText().toString());

                    call.enqueue(new Callback<Curiosity>() {
                        @Override
                        public void onResponse(Call<Curiosity> call, Response<Curiosity> response) {
                            if (response.isSuccessful()) {
                                Curiosity curiosity = response.body();
                                for (int i = 0; i < curiosity.largo(); i++) {
                                    if (nPFoto.getValue() == i) {
                                        String urlImgRecibida = curiosity.getPhotos()[i].getImgSrc();
                                        String recUrl = urlImgRecibida.replaceFirst("http", "https");
                                        Picasso.get().load(recUrl).resize(300, 300).centerCrop().into(iVFoto);
                                    }
                                }
                            }
                        }

                        @Override
                        public void onFailure(Call<Curiosity> call, Throwable t) {
                        }
                    });
                }
            }

        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}