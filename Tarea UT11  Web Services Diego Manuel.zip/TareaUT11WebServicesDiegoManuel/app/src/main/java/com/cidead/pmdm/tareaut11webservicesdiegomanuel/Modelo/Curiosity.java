
package com.cidead.pmdm.tareaut11webservicesdiegomanuel.Modelo;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Curiosity {

    private Photo[] photos;

    public Photo[] getPhotos() {
        return photos;
    }

    public void setPhotos(Photo[] photos) {
        this.photos = photos;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [photos = "+photos+"]";
    }

    public int largo(){
        return photos.length;
    }

}